"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Search, SlidersHorizontal, ChevronDown, ChevronUp, X } from "lucide-react";
import { BarisUser } from "./baris-user";

type Company = { id: number; nama: string };
type Branch = { id: number; nama: string; companyId: number | null };
type UserRow = {
  id: number;
  nama: string;
  email: string | null;
  noTelp: string | null;
  divisi: string | null;
  status: string;
  companyId: number | null;
  branchId: number | null;
  company: { nama: string } | null;
  branch: { nama: string } | null;
};

type SortField = "nama" | "divisi" | "penempatan";
type SortDir = "asc" | "desc";

export function TabelUser({
  users,
  companies,
  branches,
}: {
  users: UserRow[];
  companies: Company[];
  branches: Branch[];
}) {
  const [cari, setCari] = useState("");
  const [filterOpen, setFilterOpen] = useState(false);
  const [selectedCompanies, setSelectedCompanies] = useState<number[]>([]);
  const [selectedDivisi, setSelectedDivisi] = useState<string[]>([]);
  const [sortField, setSortField] = useState<SortField>("nama");
  const [sortDir, setSortDir] = useState<SortDir>("asc");

  const panelRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  // Tutup panel saat klik di luar area filter (tombol + panel)
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      const target = event.target as Node;
      if (
        panelRef.current &&
        !panelRef.current.contains(target) &&
        buttonRef.current &&
        !buttonRef.current.contains(target)
      ) {
        setFilterOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const divisiList = useMemo(
    () =>
      Array.from(
        new Set(users.map((u) => u.divisi).filter((v): v is string => Boolean(v)))
      ).sort(),
    [users]
  );

  function toggleCompany(id: number) {
    setSelectedCompanies((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  }

  function toggleDivisi(name: string) {
    setSelectedDivisi((prev) =>
      prev.includes(name) ? prev.filter((x) => x !== name) : [...prev, name]
    );
  }

  function resetFilter() {
    setSelectedCompanies([]);
    setSelectedDivisi([]);
  }

  const jumlahFilterAktif = selectedCompanies.length + selectedDivisi.length;

  function toggleSort(field: SortField) {
    if (sortField === field) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDir("asc");
    }
  }

  const hasil = useMemo(() => {
    const keyword = cari.trim().toLowerCase();

    let data = users.filter((u) => {
      if (
        selectedCompanies.length > 0 &&
        !selectedCompanies.includes(u.companyId ?? -1)
      ) {
        return false;
      }
      if (selectedDivisi.length > 0 && !selectedDivisi.includes(u.divisi ?? "")) {
        return false;
      }
      if (!keyword) return true;
      return [u.nama, u.email, u.noTelp, u.divisi, u.company?.nama, u.branch?.nama]
        .filter(Boolean)
        .join(" ")
        .toLowerCase()
        .includes(keyword);
    });

    data = [...data].sort((a, b) => {
      let cmp = 0;
      if (sortField === "nama") cmp = a.nama.localeCompare(b.nama);
      if (sortField === "divisi") cmp = (a.divisi ?? "").localeCompare(b.divisi ?? "");
      if (sortField === "penempatan") {
        cmp = (a.company?.nama ?? "").localeCompare(b.company?.nama ?? "");
      }
      return sortDir === "asc" ? cmp : -cmp;
    });

    return data;
  }, [users, cari, selectedCompanies, selectedDivisi, sortField, sortDir]);

  const inputClass =
    "rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500";

  return (
    <div>
      {/* Baris pencarian & tombol filter */}
      <div className="mb-3 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            value={cari}
            onChange={(e) => setCari(e.target.value)}
            placeholder="Cari nama, email, telepon, divisi, cabang..."
            className={inputClass + " w-full pl-9"}
          />
        </div>

        {/* Tombol + panel filter — dibungkus "relative" & panel di-anchor "right-0"
            supaya tidak pernah melebar keluar sisi kanan halaman */}
        <div className="relative shrink-0">
          <button
            ref={buttonRef}
            type="button"
            onClick={() => setFilterOpen((v) => !v)}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            <SlidersHorizontal className="h-4 w-4" />
            Filter
            {jumlahFilterAktif > 0 && (
              <span className="inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-indigo-600 px-1 text-xs font-semibold text-white">
                {jumlahFilterAktif}
              </span>
            )}
            {filterOpen ? (
              <ChevronUp className="h-4 w-4" />
            ) : (
              <ChevronDown className="h-4 w-4" />
            )}
          </button>

          {filterOpen && (
            <div
              ref={panelRef}
              className="absolute right-0 top-full z-30 mt-2 w-72 max-w-[calc(100vw-2rem)] rounded-xl border border-slate-200 bg-white p-4 shadow-lg sm:w-80"
            >
              <div className="mb-3 flex items-center justify-between">
                <p className="text-sm font-semibold text-slate-700">Filter Data</p>
                <button
                  type="button"
                  onClick={() => setFilterOpen(false)}
                  aria-label="Tutup filter"
                  className="rounded-lg p-1 text-slate-400 hover:bg-slate-100"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="max-h-72 space-y-5 overflow-y-auto pr-1">
                <div>
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                    Perusahaan
                  </p>
                  <div className="space-y-2">
                    {companies.map((c) => (
                      <label
                        key={c.id}
                        className="flex items-center gap-2 text-sm text-slate-600"
                      >
                        <input
                          type="checkbox"
                          checked={selectedCompanies.includes(c.id)}
                          onChange={() => toggleCompany(c.id)}
                          className="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <span className="truncate">{c.nama}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                    Divisi
                  </p>
                  <div className="space-y-2">
                    {divisiList.length === 0 && (
                      <p className="text-xs text-slate-400">Belum ada data divisi.</p>
                    )}
                    {divisiList.map((d) => (
                      <label
                        key={d}
                        className="flex items-center gap-2 text-sm text-slate-600"
                      >
                        <input
                          type="checkbox"
                          checked={selectedDivisi.includes(d)}
                          onChange={() => toggleDivisi(d)}
                          className="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <span className="truncate">{d}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              {jumlahFilterAktif > 0 && (
                <button
                  type="button"
                  onClick={resetFilter}
                  className="mt-4 w-full rounded-lg bg-slate-100 px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-200"
                >
                  Reset Filter
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      <p className="mb-2 text-xs text-slate-400">
        Menampilkan {hasil.length} dari {users.length} user.
      </p>

      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <table className="w-full min-w-[820px] text-sm">
          <thead className="bg-slate-50 text-left text-slate-600">
            <tr>
              <th className="w-14 px-4 py-3">No</th>
              <th className="px-4 py-3">
                <button
                  type="button"
                  onClick={() => toggleSort("nama")}
                  className="inline-flex items-center gap-1 hover:text-slate-800"
                >
                  Nama / Kontak <SortIcon active={sortField === "nama"} dir={sortDir} />
                </button>
              </th>
              <th className="px-4 py-3">
                <button
                  type="button"
                  onClick={() => toggleSort("divisi")}
                  className="inline-flex items-center gap-1 hover:text-slate-800"
                >
                  Divisi <SortIcon active={sortField === "divisi"} dir={sortDir} />
                </button>
              </th>
              <th className="px-4 py-3">
                <button
                  type="button"
                  onClick={() => toggleSort("penempatan")}
                  className="inline-flex items-center gap-1 hover:text-slate-800"
                >
                  Penempatan <SortIcon active={sortField === "penempatan"} dir={sortDir} />
                </button>
              </th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {hasil.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-slate-400">
                  Tidak ada user yang cocok.
                </td>
              </tr>
            ) : (
              hasil.map((user, index) => (
                <BarisUser
                  key={user.id}
                  user={user}
                  index={index}
                  companies={companies}
                  branches={branches}
                />
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function SortIcon({ active, dir }: { active: boolean; dir: SortDir }) {
  if (!active) return <span className="text-slate-300">↕</span>;
  return <span className="text-indigo-600">{dir === "asc" ? "↑" : "↓"}</span>;
}
